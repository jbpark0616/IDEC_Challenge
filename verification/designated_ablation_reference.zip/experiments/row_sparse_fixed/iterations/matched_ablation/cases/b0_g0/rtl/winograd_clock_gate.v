`timescale 1ns/1ps
// Generated ICG-OFF ablation: keep the same register update enables.
module winograd_clock_gate(input wire clk, input wire enable, output wire gclk);
    assign gclk = clk;
endmodule
